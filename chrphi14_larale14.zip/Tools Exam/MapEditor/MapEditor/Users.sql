﻿CREATE TABLE [dbo].[Users]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY , 
    [Name] VARCHAR(40) NULL UNIQUE, 
    [IsUserOn] INT NULL
)
